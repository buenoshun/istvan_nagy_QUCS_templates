<Qucs Schematic 0.0.19>
<Properties>
  <View=360,220,2205,1408,0.753367,0,0>
  <Grid=10,10,0>
  <DataSet=Channel1.dat>
  <DataDisplay=Channel1.dpl>
  <OpenDisplay=1>
  <Script=Channel1.m>
  <RunScript=0>
  <showFrame=0>
  <FrameText0=Title>
  <FrameText1=Drawn By: Istvan Nagy>
  <FrameText2=Date:>
  <FrameText3=Revision:>
</Properties>
<Symbol>
</Symbol>
<Components>
  <GND * 1 1400 540 0 0 0 0>
  <Pac P3 5 1400 510 18 -26 0 1 "2" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 1260 580 0 0 0 0>
  <Pac P5 5 1260 550 18 -26 0 1 "4" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 450 500 0 0 0 0>
  <Pac P2 5 450 470 18 -26 0 1 "1" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 500 570 0 0 0 0>
  <Pac P4 5 500 540 18 -26 0 1 "3" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 460 830 0 0 0 0>
  <Pac P6 5 460 800 18 -26 0 1 "5" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 510 910 0 0 0 0>
  <Pac P8 5 510 880 18 -26 0 1 "7" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 1410 850 0 0 0 0>
  <Pac P7 5 1410 820 18 -26 0 1 "6" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 1270 890 0 0 0 0>
  <Pac P9 5 1270 860 18 -26 0 1 "8" 1 "Z0_SYS" 1 "0 dBm" 0 "1 GHz" 0 "26.85" 0>
  <GND * 1 980 840 0 0 0 0>
  <SPfile SPAR2 1 980 780 -26 -80 0 0 "./spar_models/tracevias12inch.s4p" 0 "rectangular" 0 "linear" 0 "open" 0 "4" 0>
  <GND * 1 950 560 0 0 0 0>
  <Eqn USER_PARAMETERS 5 1720 1010 -37 18 0 0 "Z0_SYS=50" 0 "DBLOSSPERINCH_FREQ=13e9" 0 "LENGTH_SHORT=1" 1 "LENGTH_LONG=8" 1 "fmin=0.001" 0 "fmin1=fmin*1000000000" 0 "fmax=40" 1 "F0=26" 1 "freqcheck=F0" 0 "fmax1=fmax*1000000000" 0 "BAUDRATE_DATA=10" 0 "BAUDRATE_DATA1=BAUDRATE_DATA*1000000000" 0 "S11LIM_DB=12" 0 "S11LIM_UPP_DB=5" 0 "XTKLIM_DB=40" 0 "S21LIM_DB=30" 0 "S21LIM_UPP_DB=2.5" 0 "ILD_LIM1=1.5" 0 "ILD_LIM2=4" 0 "V_OUT=1" 0 "V_IN_MIN=0.15" 0 "CRC=0" 0 "GIGAHERTZ_INCH_dB=0" 0 "UNITS1=GIGAHERTZ_INCH_dB" 0 "yes" 0>
  <SPfile SPAR1 1 950 500 -26 -80 0 0 "./spar_models/tracevias5inch.s4p" 0 "rectangular" 0 "linear" 0 "open" 0 "4" 0>
  <Eqn CURVE_COMPUTATIONS 1 1650 520 -37 18 0 0 "INSERTIONLOSS_SE=dB(S[2,1])" 0 "S21SE=dB(S[2,1])" 0 "S11SE=dB(S[1,1])" 0 "SDD11=0.5*(S[1,1]-S[1,3]-S[3,1]+S[3,3])" 0 "SDD21=0.5*(S[2,1]-S[2,3]-S[4,1]+S[4,3])" 1 "SDD21B=0.5*(S[6,5]-S[6,7]-S[8,5]+S[8,7])" 1 "SDD12=0.5*(S[1,2]-S[1,4]-S[3,2]+S[3,4])" 0 "SDD22=0.5*(S[2,2]-S[2,4]-S[4,2]+S[4,4])" 0 "IL1=dB(SDD21)" 1 "IL2=dB(SDD21B)" 1 "RL1=dB(SDD11)" 0 "RL2=dB(SDD22)" 0 "ILL_FMAX=ceil(((BAUDRATE_DATA+0.01)/2))" 0 "FA_ATHALFBAUD=-1*FA[HALFBAUD_INDEX]" 0 "Gfree_INDEX=min(1023,(((freqcheck)/fmax)*1024))" 0 "G26_INDEX=min(1023,(((26)/fmax)*1024))" 0 "G13_INDEX=min(1023,(((13)/fmax)*1024))" 0 "G8_INDEX=min(1023,(((8)/fmax)*1024))" 0 "G6_INDEX=min(1023,(((6)/fmax)*1024))" 0 "FA1_free=-1*FA_1[Gfree_INDEX]" 1 "FA1_26G=-1*FA_1[G26_INDEX]" 0 "FA1_13G=-1*FA_1[G13_INDEX]" 0 "FA1_6G=-1*FA_1[G6_INDEX]" 0 "FA1_8G=-1*FA_1[G8_INDEX]" 0 "FA2_free=-1*FA_2[Gfree_INDEX]" 1 "FA2_26G=-1*FA_2[G26_INDEX]" 0 "FA2_13G=-1*FA_2[G13_INDEX]" 0 "FA2_6G=-1*FA_2[G6_INDEX]" 0 "FA2_8G=-1*FA_2[G8_INDEX]" 0 "dB_per_Inch=1" 0 "HALFBAUD_INDEX=min(1023,(((0.5*BAUDRATE_DATA)/fmax)*1024))" 0 "DELTA_LENGTH=LENGTH_LONG-LENGTH_SHORT" 1 "DBPI_6G=(abs(FA2_6G)-abs(FA1_6G))/DELTA_LENGTH" 0 "DBPI_8G=(abs(FA2_8G)-abs(FA1_8G))/DELTA_LENGTH" 0 "DBPI_13G=(abs(FA2_13G)-abs(FA1_13G))/DELTA_LENGTH" 0 "DBPI_26G=(abs(FA2_26G)-abs(FA1_26G))/DELTA_LENGTH" 0 "DBPI_free=(abs(FA2_free)-abs(FA1_free))/DELTA_LENGTH" 1 "IL_END=min(IL1)" 0 "ILBOT_RANGE=linspace(0,0,25)" 0 "ILBOT_RANGEB=linspace(0,0,25)" 0 "ILTOP_RANGE=linspace(IL_END,IL_END,200)" 0 "ILTOP_RANGEB=linspace(IL_ENDB,IL_ENDB,200)" 0 "IL_EXTENDED=[ILBOT_RANGE,IL1,ILTOP_RANGE]" 0 "ILFITTED=runavg(IL_EXTENDED,50)" 0 "ILFITTEDB=runavg(IL_EXTENDEDB,50)" 0 "FA1runavg=runavg(ILFITTED,50)" 0 "FA2runavg=runavg(ILFITTEDB,50)" 0 "favg=0.3*25e9" 0 "faindex1=1023*((0.1*freqcheck)/fmax)" 0 "faindex2=1023*((freqcheck)/fmax)" 0 "ILavg=avg(IL1[faindex1:faindex2])" 0 "ILavg2=avg(IL2[faindex1:faindex2])" 0 "ma1=frequency-favg" 0 "ma1b=ma1[faindex1:faindex2]" 0 "ma2=IL1-ILavg" 0 "ma22=IL2-ILavg2" 0 "ma2b=ma2[faindex1:faindex2]" 0 "ma2b2=ma22[faindex1:faindex2]" 0 "ma=sum(ma1b*ma2b)/sum(ma1b*ma1b)" 0 "mab=sum(ma1b*ma2b2)/sum(ma1b*ma1b)" 0 "ba=ILavg-ma*favg" 0 "ba2=ILavg2-mab*favg" 0 "FA1ap=(ma*frequency)+ba" 0 "FA2ap=(mab*frequency)+ba2" 0 "ILDEV=FA-IL1" 0 "FA=FA_1" 0 "ILFITTED2=ILFITTED*(IL1/IL1)" 0 "IL_ENDB=min(IL2)" 0 "IL_EXTENDEDB=[ILBOT_RANGEB,IL2,ILTOP_RANGEB]" 0 "ANGLEX=phase(S[2,1])" 0 "maxtime=1000*1024/(2*fmax)" 0 "timme=linspace(0,maxtime,1024)" 0 "FA1_F1=freqcheck/5" 0 "FA1_F2=freqcheck" 0 "FA1IL1=-2*avg(IL1[0:(1+floor(1023*((FA1_F1)/(fmax))))])" 0 "FA1IL2=-2*avg(IL1[0:Gfree_INDEX])" 0 "FA1_PARA=-0.77*(FA1IL1*FA1_F2-FA1IL2*FA1_F1)/(sqrt(FA1_F1)*FA1_F2-sqrt(FA1_F2)*FA1_F1)" 0 "FA1_PARB=-1*(FA1IL2*sqrt(FA1_F1)-FA1IL1*sqrt(FA1_F2))/(sqrt(FA1_F1)*FA1_F2-sqrt(FA1_F2)*FA1_F1)" 0 "FA1bj=FA1_PARA*sqrt(frequency/1e9)+FA1_PARB*frequency/1e9" 0 "FA2IL1=-2*avg(IL2[0:(1+floor(1023*((FA1_F1)/(fmax))))])" 0 "FA2IL2=-2*avg(IL2[0:Gfree_INDEX])" 0 "FA2_PARA=-0.77*(FA2IL1*FA1_F2-FA2IL2*FA1_F1)/(sqrt(FA1_F1)*FA1_F2-sqrt(FA1_F2)*FA1_F1)" 0 "FA2_PARB=-1*(FA2IL2*sqrt(FA1_F1)-FA2IL1*sqrt(FA1_F2))/(sqrt(FA1_F1)*FA1_F2-sqrt(FA1_F2)*FA1_F1)" 0 "FA2bj=FA2_PARA*sqrt(frequency/1e9)+FA2_PARB*frequency/1e9" 0 "FA_1=FA1bj" 1 "FA_2=FA2bj" 1 "yes" 0>
  <.SP SP1 5 1610 390 0 96 0 0 "lin" 0 "fmin1" 0 "fmax1" 0 "1024" 0 "no" 0 "1" 0 "2" 0 "no" 0 "no" 0>
</Components>
<Wires>
  <740 530 920 530 "" 0 0 0 "">
  <720 470 920 470 "" 0 0 0 "">
  <1160 520 1260 520 "" 0 0 0 "">
  <1190 480 1400 480 "" 0 0 0 "">
  <720 470 720 490 "" 0 0 0 "">
  <590 490 720 490 "" 0 0 0 "">
  <740 510 740 530 "" 0 0 0 "">
  <500 510 740 510 "" 0 0 0 "">
  <450 430 450 440 "" 0 0 0 "">
  <450 430 590 430 "" 0 0 0 "">
  <590 430 590 490 "" 0 0 0 "">
  <1160 520 1160 530 "" 0 0 0 "">
  <980 530 1160 530 "" 0 0 0 "">
  <1190 470 1190 480 "" 0 0 0 "">
  <980 470 1190 470 "" 0 0 0 "">
  <460 760 460 770 "" 0 0 0 "">
  <460 760 610 760 "" 0 0 0 "">
  <610 760 610 780 "" 0 0 0 "">
  <610 800 610 850 "" 0 0 0 "">
  <510 850 610 850 "" 0 0 0 "">
  <610 800 880 800 "" 0 0 0 "">
  <610 780 890 780 "" 0 0 0 "">
  <1040 790 1270 790 "" 0 0 0 "">
  <1040 770 1410 770 "" 0 0 0 "">
  <1410 770 1410 790 "" 0 0 0 "">
  <1270 790 1270 830 "" 0 0 0 "">
  <1040 790 1040 810 "" 0 0 0 "">
  <1010 810 1040 810 "" 0 0 0 "">
  <880 800 880 810 "" 0 0 0 "">
  <880 810 950 810 "" 0 0 0 "">
  <1040 750 1040 770 "" 0 0 0 "">
  <1010 750 1040 750 "" 0 0 0 "">
  <890 750 890 780 "" 0 0 0 "">
  <890 750 950 750 "" 0 0 0 "">
</Wires>
<Diagrams>
  <Rect 544 1302 709 305 3 #c0c0c0 1 00 1 0 5e+09 4e+10 1 -27.2656 5 2.92773 1 -1 0.5 1 315 0 225 "frequency" "" "">
	<"IL1" #0000ff 3 3 0 0 0>
	<"FA_1" #008f8f 0 3 0 1 0>
	<"FA_2" #ff00ff 0 3 0 1 0>
	<"IL2" #ff0000 3 3 0 0 0>
  </Rect>
  <Tab 1300 1297 817 77 3 #c0c0c0 1 00 1 0 1 1 1 0 1 1 1 0 1 1 315 0 225 "" "" "">
	<"DBPI_13G" #0000ff 0 3 1 0 0>
	<"DBPI_6G" #0000ff 0 3 1 0 0>
	<"DBPI_8G" #0000ff 0 3 1 0 0>
	<"DBPI_26G" #0000ff 0 3 1 0 0>
	<"DBPI_free" #0000ff 0 3 1 0 0>
  </Tab>
</Diagrams>
<Paintings>
  <Rectangle 1230 460 300 160 #005500 2 2 #c0c0c0 1 0>
  <Text 1230 430 10 #000000 0 "SIMULATION PORTS">
  <Rectangle 420 420 230 190 #005500 2 2 #c0c0c0 1 0>
  <Text 420 390 10 #000000 0 "SIMULATION PORTS">
  <Text 420 720 10 #000000 0 "SIMULATION PORTS">
  <Rectangle 420 750 230 200 #005500 2 2 #c0c0c0 1 0>
  <Text 1230 720 10 #000000 0 "SIMULATION PORTS">
  <Rectangle 1230 750 300 180 #005500 2 2 #c0c0c0 1 0>
  <Text 400 260 26 #ff0000 0 "DELTA-L COMPUTATION FOR INSERTION LOSS COUPONS">
  <Text 950 680 10 #ff0000 0 "BROWSE S-par FILE 2">
  <Text 930 400 10 #ff0000 0 "BROWSE S-par FILE 1">
  <Text 700 350 18 #000000 0 "SHORT TRACE">
  <Text 720 880 18 #000000 0 "LONG TRACE">
  <Text 1310 1180 14 #000000 0 "LOSS dB/INCH@F0 RESULTS :">
  <Text 1790 990 14 #ff0000 0 "USER ENTER HERE">
  <Text 1970 1030 12 #000000 0 "INCH\nINCH\nGHz\nGHz">
</Paintings>
