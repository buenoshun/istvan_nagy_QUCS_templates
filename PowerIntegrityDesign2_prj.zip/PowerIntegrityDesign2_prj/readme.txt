This prower integrity design template was developed by Istvan Nagy 2008-2021.
It is a template project file that the user can modify, and run in the open sorce QUCS software.
It is freeware and open source, can be used for home, academic or commercial projects without limitation.
The GPL license applies.


Required:
1.
QUCS software v0.019 or newer. (tested on 0.0.19)
https://sourceforge.net/projects/qucs/files/qucs-binary/0.0.19/
Istall windows binary. 
2.
ASCO optimizer v0.4.11 or newer commandline tool
v0.4.11 should be released around December 2021.
Downlaod from: 
https://sourceforge.net/projects/asco/files/asco/
Then copy the ASCO.EXE file into the QUCS install directory "bin" subfolder, to overwrite the older version there.


Provided model files:
1.
vrm subfolder contains a few simple S-parameter files that represent common voltage regulators. Most of these were not measured with VNA, but manually typed in, and rely on the simulator interpolation. One model was actually measured that have different prost-processed variants. Smoothed, scaled and one variant with ideal high frequency part.
2.
sonnetlite_powerplane subfolder, containing power plane models, in S-parameter format, and in SonnetLite model that can be modified and rerun in the freeware SonnetLite software.


PDN model elements:
- Capacitors with RLC parameters
- Voltage regulators with VNA-measured S-parameter model. Use Bode-100 or Keysight E5061B-3.
- Power planes with 2D-EM simulated S-parameter models
- ASIC pin models auto-calculated based on ESL and number of pins


Usage:
- Before the first use, select a VRM S-parameter file, from the VRM folder or use your own measured model. 
- If using your own measured VRM model, use the spar_smoothie.xls to remove noise.
- Set system parameters like Voltage, delta current, tolerance and upper frequency limit.
- Set capacitor parameters and quantities.
- Press the cog-wheel icon to run simulations. 
- The results will be on the main page.


Capabilities:
There are several different types of simulations that can be run, and depending on the choice, some elements have to be dectivated using the red X-symbol. Multiple equation blocks can be enabled in the same time.
Simulation types:
- simple AC-sim to generate impedance profile with target impedance. (run time 5sec)
- PDN flatness score/metric computation. 
- Capacitor-pair Q-factor computation. 
- Rogue wave amplitude computation with 3 different methods: 
  MTT, RPT, Nuke. (run time 5sec for MTT, 7minutes for RPT and Nuke)
- Optimization simulation to obtain ideal capacitor quantities or BOM.
  RPT must be disabled to run the optimizer. (run time 1 hour)
- Display measured data and compare against simulation



